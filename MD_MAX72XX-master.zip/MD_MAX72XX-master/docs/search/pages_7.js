var searchData=
[
  ['parola_20custom_20module',['Parola Custom Module',['../page_parola.html',1,'pageHardware']]]
];
