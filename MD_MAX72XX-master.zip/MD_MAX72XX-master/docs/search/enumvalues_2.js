var searchData=
[
  ['off',['OFF',['../class_m_d___m_a_x72_x_x.html#aadaf745b81100652dafeff2eb212f457a69c74295de1c864d082152eb358409a1',1,'MD_MAX72XX']]],
  ['on',['ON',['../class_m_d___m_a_x72_x_x.html#aadaf745b81100652dafeff2eb212f457aa19c4a20e024758f7cb4b82283ef2138',1,'MD_MAX72XX']]]
];
